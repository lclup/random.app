package com.lwy.lwy;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity  {
    private
    EditText ed1;
    EditText ed2;
    Button   bt1;
    Button   bt2;
    Button   bt3;
    TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1 = findViewById(R.id.editTextNumber);
        ed2 = findViewById(R.id.editTextNumber2);
        bt1 = findViewById(R.id.button3);
        bt2 = findViewById(R.id.button4);
        bt3 = findViewById(R.id.button5);
        tv1 = findViewById(R.id.textView);
        bt2.setOnClickListener(new View.OnClickListener() {
                                   public void onClick(View v) {
//                产生随机数
                                       Random rand = new Random();
                                       String maxbuf = (ed1.getText()).toString();
                                       String minbuf = (ed2.getText()).toString();
                                       System.out.println( maxbuf);
                                       String maxbb="123";


                                       int max = Integer.valueOf(maxbuf).intValue();
                                       int min = Integer.valueOf(minbuf).intValue();


                                       int randNumber = rand.nextInt(max-min+1) + min;
                                       String num=Integer.toString(randNumber);
                                       tv1.setText("");
                                       tv1.setText(num);
                                   }
        });
               bt1.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {

                    ed1.setText("");
                    ed2.setText("");
                }
               });
        bt3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                tv1.setText("");
            }
        });














    }
}